package com.example.devotion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
