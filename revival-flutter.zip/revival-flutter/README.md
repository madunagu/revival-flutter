# devotion

trying to implement this design
[mockup](https://www.behance.net/gallery/72907227/Meetio-UI-Kit)